// IO.c
// This software configures the switch and LED
// You are allowed to use any switch and any LED, 
// although the Lab suggests the SW1 switch PF4 and Red LED PF1
// Runs on LM4F120 or TM4C123
// Program written by: Goon Squad 
// Date Created: March 30, 2018
// Last Modified: 4/1/18
// Lab number: 7


#include "../inc/tm4c123gh6pm.h"
#include <stdint.h>
#include "ST7735.h"  

//------------IO_Init------------
// Initialize GPIO Port for a switch and an LED
// Input: none
// Output: none
void IO_Init(void) {
 // --UUU-- Code to initialize PF4 and PF2
	SYSCTL_RCGC2_R |= 0x20;
	SYSCTL_RCGCGPIO_R |= 0x20; 
	Delay1ms(1);
	SYSCTL_RCGCGPIO_R |= GPIO_LOCK_KEY; //for PF4
	GPIO_PORTF_CR_R |= 0xFF; 			//for PF4 
	GPIO_PORTF_DIR_R &= (~0x10);		//pin 4 is an input 
	GPIO_PORTF_DIR_R |= 0x12;			//pin 2 is an output 
	GPIO_PORTF_DEN_R |= 0x12; 			
}

//------------IO_HeartBeat------------
// Toggle the output state of the  LED.
// Input: none
// Output: none
void IO_HeartBeat(void) {
 // --UUU-- PF2 is heartbeat
	GPIO_PORTF_DATA_R ^=0x2;
	//is this suppose to be left automatic or is this fuction suppose to manually toggle it

}


//------------IO_Touch------------
// wait for release and press of the switch
// Delay to debounce the switch
// Input: none
// Output: none
void IO_Touch(void) {
 // --UUU-- wait for release; delay for 20ms; and then wait for press
	while((GPIO_PORTF_DATA_R&0x10)==0x10){}		//contiunes through loop while button is pressed 
		Delay1ms(20);
	while((GPIO_PORTF_DATA_R&0x10)==0x0){}		//contiunes through loop while button isnt not pressed 
}  


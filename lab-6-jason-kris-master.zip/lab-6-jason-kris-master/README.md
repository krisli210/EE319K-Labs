# Lab-6
Digital Piano using a 4-bit DAC, written in C (simulated and board, groups of two)
